package as400;

public class ZbxException extends Exception {
    private static final long serialVersionUID = 1L;

    public ZbxException(String message) {
        super(message);
    }//constrictor ZbxException()

}//class ZbxException
