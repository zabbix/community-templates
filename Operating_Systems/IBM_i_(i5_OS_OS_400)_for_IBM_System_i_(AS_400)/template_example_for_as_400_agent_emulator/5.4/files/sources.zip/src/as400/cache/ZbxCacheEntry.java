package as400.cache;

public interface ZbxCacheEntry {

    public void appendToStringBuilder(StringBuilder buf);

}//interface ZbxCacheEntry
